let a1 = true;
console.log(a1,typeof a1);

if(a1){
    console.log("TRUE");

}

let a2 = "";                                    //false
if(a2){
    console.log("Might be true");
}

let a3 = "Hello";
if(a3){
    console.log("Will I execute");
}
let a4 = 0;                                 //false
if(a2){
    console.log("Might be true");
}