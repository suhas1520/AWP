var a = {};
a.key1 = "Value1";
a["key2"] = "Value2";

var b = {
  firstName: "Xyz",
  lastName: "Pqr",
  age: 24,
  gender: "M",
  walk: function(){
    return this.fullName + " is walking";
  },
  get fullName(){
    return this.firstName + " " + this.lastName;
  },
  set setGender(g){
    this.gender = g;
  },
  get getGender(){
    return this.gender;
  }
}

b.getGender
b["setGender"] = "M";
b.getGender
b.fullName
console.log(b.walk())

function Student()
{
  if(arguments.length < 3)
  {
    console.log("Please send fullname, roll, age at least...");
    return false;
  }
  var age 		= arguments[2];;
  var about 	= arguments[3];
  var fullname 	= arguments[0];;
  var roll 		= arguments[1];;
  console.log(fullname + "-"  + roll + "-" + age + "-" + about);
}

Student("Rohit Shetty", 23);
Student("Kirti Sharma", 12, 16, "Welcome321");

//Adding members to the Constructor
function Student(fullname, roll, age, about)
		{
			// Private data members are created using 'var' keyword
			var age 		= age;
			var about 	= about;

			// public data members are created using 'this' keyword
			this.fullname 	= fullname;
			this.roll 		= roll;
			
			this.getAge = function()
			{
				return age;
			}
		}

		var s1 = new Student("Rohit Shetty", 23, 18, "Welcome123");

s1.doSomething = function()
{
  return this.fullname + " is doing something";
}

var s2 = new Student("Kirti Sharma", 12, 16, "Welcome321");

s1.doSomething()
//s2.doSomething()

Student.prototype.walk = function()
{
  return this.fullname + " is walking...";
}

s1.walk();
s2.walk();


//
// Define the Person constructor
var Person = function(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
};

var p1 = new Person("Rohit", "Sharma");

// Add a couple of methods to Person.prototype
Person.prototype.walk = function(){
  console.log(this.firstName + " is walking!");
};

Person.prototype.sayHello = function(){
  console.log("Hello, I'm " + this.firstName + " " + this.lastName);
};

// Define the Student constructor
function Student(firstName, lastName, subject)
{
	Person.call(this, firstName, lastName);
	this.subject = subject;
}

		Student.prototype = Object.create(Person.prototype); 
		
		Student.prototype.constructor = Student;

		Student.prototype.sayHello = function(){
		  console.log("Hello, I'm " + this.firstName + " " + this.lastName + ". I'm studying "
				      + this.subject + ".");
		};

		Student.prototype.sayGoodBye = function(){
		  console.log("Goodbye student!");
		};

		var student1 = new Student("Janet", "Something", "Applied Physics");
		student1.sayHello();
		student1.walk();
		student1.sayGoodBye();

		Person.prototype.sayGoodBye = function(){
		  console.log("Goodbye!");
		};

		p1.sayGoodBye();
		delete Person.prototype.sayGoodBye;	
		p1.sayGoodBye();
	
new Date(1276387162388)

//UNIX epoch time => 00:00:00, 1 Jan, 1970 .. till now milliseconds

var d1 = new Date("Dec 5, 2021 13:26:34")
d1
d1.getDay()
d1.getDate()
d1.getFullYear()

d2 = new Date();
d2.setDate(5)
d2.setMonth(11)
d2.setFullYear(2021)
d2.setHours(13)
d2.setMinutes(26)
d2.setSeconds(34)
d2.setMilliseconds(349)

d1 < d2
d1.getMilliseconds()
d2.getMilliseconds()
		