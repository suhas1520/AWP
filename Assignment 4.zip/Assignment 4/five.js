let str = "Swapnali";
let str1 = 'Suniti';
let str2 = `Supriya`;

let str3 = str  + str1 + str2 ;

console.log(str3);

let str4 = `StringTild ${str} ${str1} ${str2}`;
console.log(str4);

let limit = 10;
let start = 0;
let url = "https://jsonplaceholder.typicode.com/posts?_start=" +start +"&_limit=" +limit;
let url1 =  `https://jsonplaceholder.typicode.com/posts?_start=${start}&_limit=${limit}`;

console.log(url);
console.log(url1);

https://dacroom.web.app/home
