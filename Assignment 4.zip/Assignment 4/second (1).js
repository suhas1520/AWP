class Second{
    static main(x,y){
        console.log("Static block");
        console.log(x+y);
    }
    hello()
    {
        console.log("hello world");

    }
}

Second.main(2,3);
let sec = new Second();
sec.hello();
