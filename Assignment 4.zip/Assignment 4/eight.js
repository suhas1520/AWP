let str = new String("Hello World");
console.log(str);