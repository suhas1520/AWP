 let str ="hello world";
let num = 100;
let num1 =200;
let str1 ="hello universe";

let concat =str + num + str1;

let concat = ${str}   +${num}
let total =num + num1;


console.info(total, concat);
==============================================


//pattrn

for(let i=0;i<5;i++){
let star="";
for(j=0;j<=i; j++{
 star+="*";
}
}
==============================================
console.log("cammand line arg demo");

console.log(process.argv);


let count =process.argv[2];
if(count==undefined){
count=5;
}
or
const count=process.argv[2] ||5;

//convert string to num

const num = parseInt(count);

console.log(count);
==============================================

fuctionss
  function main(parameter){.......}








