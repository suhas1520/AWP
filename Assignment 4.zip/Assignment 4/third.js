// Global scope

var str = "Hello Var";
let str1 = "Hello Let";
const str2 = "Hello Const";

console.log(str, str1, str2);

// TRY TO RE-DECLARE
var str = "Var Again";
// let str1 = "Let Again";
str1 = "Let Again";

// const str2 = "Const Again";

str2 = "Const Again";

console.log(str, str1, str2);
