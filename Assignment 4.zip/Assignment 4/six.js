let str = `Hello World`;
let num = 10;
let pi = 3.14;

console.log(str);
console.log(num);
console.log(pi);