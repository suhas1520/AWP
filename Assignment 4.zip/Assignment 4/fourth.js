//global var
let str = "hello";

for(let i=0;i<5;i++)
{
    let str = "World";       //block scope
    console.log(i,str);

    for(let i=0;i<5;i++)
    {
        let str = "EDAC";       //block scope
        console.log(i,str);
    
        
    }
}

